# Native simulator GUI design

## Review of the supplied notes

The notes combine standards, examples from working projects, and the author's
toolkit recommendations. They provide design input for HEPLab. Several source
labels in the notes lack links, so claims about prevalence, official adoption,
and the reasons behind migrations need separate evidence. Qt with
OpenGL is one supported desktop path in Geant4. Phoenix demonstrates an
independent web event-display path. These examples establish precedent for
multiple toolkits for particle physics. [Geant4 visualization drivers](https://geant4.web.cern.ch/documentation/dev/bfad_html/ForApplicationDevelopers/Visualization/visdrivers.html) · [HEP Software Foundation visualization white paper](https://arxiv.org/abs/1811.10309) · [Phoenix source](https://github.com/HSF/phoenix)

ISO 9241-110 provides general interaction principles for evaluating the student
workflow. ISA-101 addresses industrial operator displays. The idea of a written
HMI philosophy transfers to HEPLab as an explicit hierarchy for run state,
results, and scientific scope. An educational simulator has a different
operating context from an industrial control room. [ISO 9241-110](https://www.iso.org/standard/75258.html) · [ISA-101 standards](https://www.isa.org/standards-and-publications/isa-standards/isa-101-standards)

## Interaction requirements

| Practice from the notes | HEPLab behavior | Acceptance |
| --- | --- | --- |
| Event-by-event navigation and linked projections | In an event-capable workspace, the event ID and selected object stay stable across the detector tree, XY/XZ views, 3D view, and table. Geometry toggles change visibility only. | Select an object from a table and identify the same object in both views. Step to the next event and clear stale selection. |
| Task-oriented display hierarchy | Put the source and scope beside the main result. Place controls near the affected view, with explicit units, cuts, and a visible path to provenance. | From an exported result, identify the event source, selection, units, fit uncertainty, and checkpoint count without opening the raw JSON. |
| Use display space for evidence | Use a chart and a table backed by the same saved bins. Provide keyboard navigation and use text alongside visual status. | Switch from cutflow to mass bins by keyboard and read the counts without using the chart. |
| Error tolerance | Keep the last successfully opened result visible if a new file is malformed. Explain the problem near the file-open action. | Open a valid export, then a malformed file, and check the active plot survives. |
| Prototype evaluation | Observe students using the complete predict, configure, run, inspect, and replay workflow. Evaluate the result display separately from simulation fidelity. | Record task completion, navigation errors, and whether students can explain what the synthetic peak measures. |

Docking and a contextual command console can help an expert workspace once those
tasks are established. A first-time learner needs a predictable layout with a visible
next action. Use further educator and student testing to decide when more controls
belong on the default surface.

## Workbench development

The [desktop Workbench](desktop-shell.md) owns the simulator interface. Open
`desktop/HEPLab.Workbench.sln` in Microsoft Visual Studio Insiders to build and
launch it. Its top bar gives direct access to Simulation, CMS data, event
inspection, validation, and the Z-boson lab.

The earlier standalone Qt workbench and C++ result viewer are archived under
`legacy/desktop-prototypes/`. Their UI experiments provide source material for
improvements within the Workbench.
